package Model.Sintatico;

public enum TipoToken {
    MES,

    LUGAR,

    PRODUTO,

    VEICULO,

    PERIODO,

    LOCAL,

    EVENTO,

    PAGAMENTO,

    SITUACAO,

    FERIADO
}