package Model;

public enum QueryClassification {
    OK,
    LESS,
    MANY,
    ERROR
}
